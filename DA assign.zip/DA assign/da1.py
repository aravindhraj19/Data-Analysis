# 📄 People Classification Model

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from google.colab import files

# Step 1: Upload and load the CSV
uploaded = files.upload()
data = pd.read_csv(next(iter(uploaded)))
data.columns = data.columns.str.lower().str.replace(" ", "_")

# Step 2: Encode categorical columns if any
for col in data.select_dtypes(include='object').columns:
    data[col] = LabelEncoder().fit_transform(data[col])
print("✅ Encoded categorical columns.")

# Step 3: Create a target column — classify people older than 30 (example)
if 'age' in data.columns:
    data['target'] = (data['age'] > 30).astype(int)
    print("🎯 Target column created based on 'Age > 30'.")
else:
    raise ValueError("No 'age' column found to create target!")

# Step 4: Select features (drop irrelevant columns)
features = data.drop(columns=['target'])
X = features
y = data['target']

# Step 5: Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Train classifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)

# Step 7: Predict and evaluate
y_pred = model.predict(X_test)
print("📊 Classification Report:\n")
print(classification_report(y_test, y_pred))

# Step 8: Confusion matrix
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='YlGnBu')
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.show()
