# 📊 Simple People Classification with Confusion Matrix

import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from google.colab import files

# Step 1: Upload and load the dataset
uploaded = files.upload()
data = pd.read_csv(next(iter(uploaded)))
data.columns = data.columns.str.lower().str.replace(" ", "_")

# Step 2: Check for categorical columns and encode them
for col in data.select_dtypes(include='object').columns:
    data[col] = LabelEncoder().fit_transform(data[col])
print("✅ Encoded all object (text) columns.")

# Step 3: Create a target variable (Example: Classify if Age > 30)
if 'age' in data.columns:
    data['target'] = (data['age'] > 30).astype(int)
    print("🎯 Target column created: 'age > 30'")
else:
    raise ValueError("No 'age' column found to create target.")

# Step 4: Feature selection (use all except target)
features = [col for col in data.columns if col != 'target']
X = data[features]
y = data['target']

# Step 5: Normalize numeric features
X = StandardScaler().fit_transform(X)

# Step 6: Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# Step 7: Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Step 8: Evaluation
print("📊 Classification Report:\n")
print(classification_report(y_test, y_pred))

# Step 9: Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
labels = ['Age <= 30 (0)', 'Age > 30 (1)']

plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels, cbar=False)
plt.title("🧩 Confusion Matrix - Age Classification")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.tight_layout()
plt.show()
